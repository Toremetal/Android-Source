/*
 *    ™T©ReMeTaL Signs A-Z.
 *    Copyright (C) 2022 ™T©ReMeTaL.
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *
 *    Some functionality created with modified (code) lessons provided by:
 *    The Android Open Source Project.
 *    Copyright (C) 2022 The Android Open Source Project.
 *    Licensed under the Apache License, Version 2.0 (the "License").
 *
 *    You may obtain a copy of the License at
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 *
 *   ************************************************************************
 *     MainActivity.kt : Copyright (c) 2022 ™T©ReMeTaL.
 *   ************************************************************************
 *      Computer Scientist: David W. Rick
 *      Date: 8/16/22, 1:48 AM
 *      Program Name: SignsFree
 *      File: MainActivity.kt
 *      Last Modified: 8/15/22, 4:48 PM
 *   ************************************************************************
 */

package com.toremetal.signsfree

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.*
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.app.AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
import androidx.appcompat.widget.SwitchCompat
import androidx.core.app.ActivityCompat.recreate
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.drawerlayout.widget.DrawerLayout
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import androidx.preference.PreferenceManager
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.appodeal.ads.Appodeal
import com.facebook.FacebookSdk
import com.facebook.FacebookSdk.setAdvertiserIDCollectionEnabled
import com.facebook.FacebookSdk.setAutoLogAppEventsEnabled
import com.facebook.ads.AudienceNetworkAds
import com.google.android.gms.ads.MobileAds
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.navigation.NavigationView
import com.google.android.material.snackbar.BaseTransientBottomBar.ANIMATION_MODE_SLIDE
import com.google.android.material.snackbar.Snackbar
import com.google.android.play.core.appupdate.AppUpdateManagerFactory
import com.google.android.play.core.appupdate.AppUpdateOptions
import com.google.android.play.core.install.model.AppUpdateType
import com.google.android.play.core.install.model.UpdateAvailability
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.analytics.ktx.analytics
import com.google.firebase.ktx.Firebase
import com.toremetal.signsfree.MainActivity.MyNavView.mainActivity
import com.toremetal.signsfree.MainActivity.MyNavView.showMessage
import com.toremetal.signsfree.data.checkUpdate
import com.toremetal.signsfree.data.textToTranslStr
import com.toremetal.signsfree.data.translate
import com.toremetal.signsfree.databinding.ActivityMainBinding
import java.io.OutputStreamWriter
import java.util.*


/* =============================================================
*      ContextCompat.getColor(this.context, R.color.red)
*
*     This method for retrieving color doesn't trigger the:
*       method requires API 23 call current min is 21.
* =========================================================== */

/**
 * Global Ad-stop Switch for debugging.
 *
 * set: { const val [showAppAds]: Boolean = true } for release.
 */
const val showAppAds: Boolean = true

/**
 * Global display Error-Message Switch for debugging.
 *
 * set: { const val [showErrorMessage]: Boolean = false } for release.
 */
const val showErrorMessage: Boolean = false

/**
 * Function [refreshMyScrn] applies changes made by fragments that require an app refresh to work
 * properly. Without this the app needs to be rotated or restarted to properly activate the custom
 * library. Which likely caused the app to appear as a total piece of crap to end users.
 * This may be the solution to using fragments and getting smooth productivity.
 *
 *   note: ***Requires
 *
 *      fun refreshMyScrn() {
 *          recreate(mainActivity)
 *      }
 *      class MainActivity : AppCompatActivity() {
 *          companion object MyNavView {
 *              lateinit var mainActivity: MainActivity
 *          }
 *          override fun onCreate(savedInstanceState: Bundle?) {
 *              super.onCreate(savedInstanceState)
 *              binding = ActivityMainBinding.inflate(layoutInflater)
 *              setContentView(binding.root)
 *              mainActivity = this
 *          }
 *      }
 */
fun refreshMyScrn(mes: String = "") {
    recreate(mainActivity)
    if (mes != "") {
        showMessage(mes)
    }
}

/**
 * External function: [tLater] is used to pass user input
 * to the Internal function: [MainActivity.setTxtWebInput]
 * to set the text in the web-search text-box.
 */
fun tLater(str: String) {
    mainActivity.setTxtWebInput(str)
}

/**
 * Turns the translator buttons & text box back on.
 */
fun showTranslator() {
    mainActivity.showTheTranslator()
}

/**
 * Turns the translator buttons & text box off (hides).
 */
fun hideTranslator() {
    mainActivity.hideTranslator()
}

/**
 * [MainActivity] The primary container for the application.
 */
class MainActivity : AppCompatActivity() {
    private var consentForm: com.explorestack.consent.ConsentForm? = null
    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActivityMainBinding
    private lateinit var firebaseAnalytics: FirebaseAnalytics

    /**
     * Internal function to set the text in the webSearch text-box.
     */
    fun setTxtWebInput(newText: String) {
        val textHome = findViewById<EditText>(R.id.textHome)
        val txt = "${textHome.text}$newText"
        textHome.setText(txt)
        textHome.setSelection(textHome.text.length)
        //textHome.setSelection(textHome.editableText.lastIndex.plus(1))
    }

    /** [UPDATE! Problem Solved Using: refreshMyScrn() ]
     * Seeking best method to allow fragment to enable/disable menu option at log in/out.
     *   note: it works inconsistently. logcat seems to display this error on log in.
     *   E/ERROR: Only the original thread that created a view hierarchy can touch its views.
     */
    companion object MyNavView {
        /**
         * The [APPODEAL_APP_ID] Appodeal app id.
         */
        const val APPODEAL_APP_ID: String = getString(R.string.APPODEAL_APP_ID)

        /** Options:
         * Appodeal.INTERSTITIAL | Appodeal.REWARDED_VIDEO | Appodeal.INTERSTITIAL
         * Appodeal.NATIVE | Appodeal.MREC | Appodeal.BANNER.
         */
        const val AD_TYPE: Int = Appodeal.BANNER

        /**
         * [navView] Nav Menu assigned as a global var to allow fragments to disable options.
         */
        lateinit var navView: NavigationView

        /**
         * Var [mainActivity] is the handle used to refresh the application allowing
         * any changes made to fully take effect giving accurate feedback to the user.
         *
         *      note: This may allow the perform click to work requesting it this
         *           way may be how to get the call to come from the same library.
         */
        lateinit var mainActivity: MainActivity

        /**
         * function to activate/deactivate nav menu options
         *
         *  note: currently used for 1 option. Add an Int variable to get different menu items.
         *
         *      fun menuButtonOn(on: Boolean, item: Int) {
         *          navView.menu.getItem(item).isEnabled = on
         *      }
         */
        fun menuButtonOn(on: Boolean) {
            try {
                navView.menu.getItem(4).isEnabled = on
                navView.menu.getItem(5).isEnabled = on
            } catch (e: Exception) {
                errorReport(
                    errStr = "[MA-238]${e.message}",
                    errorDetails = e.stackTraceToString()
                )
            }
        }

        /**
         * (User Optional Error Reporting.) Error Logged by the host site.
         */
        fun errorReport(errStr: String, errorDetails: String = "") {
            val sharedPreferences =
                PreferenceManager.getDefaultSharedPreferences(this.navView.context /* Activity context */)
            if (sharedPreferences.getBoolean("sendErrors", false)) {
                var details = ""
                if (sharedPreferences.getBoolean("detail", false)) {
                    details = "&detail=$errorDetails"
                }
                try {
                    val queue = Volley.newRequestQueue(this.navView.context)
                    val url = "https://toremetal.com/log/?error=$errStr$details&app=SignsA-Z"
                    // Request a string response from the provided URL.
                    val stringRequest = StringRequest(
                        Request.Method.POST, url,
                        { response ->
                            val vx: CharSequence = "Not Logged"
                            if (response.contains(vx, ignoreCase = false)) {
                                if (showErrorMessage) {
                                    showMessage("[Log Error:] $response")
                                }
                            } else {
                                if (showErrorMessage) {
                                    showMessage(response)
                                }
                            }
                        }, {
                            this.errorReport(
                                errStr = "[MA-239]${it.message}",
                                errorDetails = it.stackTraceToString()
                            )
                        })
                    queue.add(stringRequest)
                } catch (e: Exception) {
                    this.errorReport(
                        errStr = "[MA-245]${e.message}",
                        errorDetails = e.stackTraceToString()
                    )
                }
            }
        }

        /**
         * Function: [showMessage] displays a popup message to the user.
         *
         *   note: SnackBar does not work when passing messages BETWEEN fragments on view change,
         *
         *      Must use:
         *        Toast.makeText(this.navView.context, mes, Toast.LENGTH_SHORT).show()
         *
         *     To use this showMessage on View Changing events. Static-view messages display
         *     fine. However, when the view is switching there is no View?. for the SnackBar
         *     whereas the Toast uses App {context} not an Active {view} which doesn't
         *     dispose() during View Changing events. (theoretical, but logical.)
         *
         *       note2:
         *       Could Global function this outside the class & pass the context to it.
         *          this would eliminate the need for a companion object.
         *          fun showMessage(mes: String, context: Context) {}
         *
         *          toUse: showMessage("", this.requireContext())
         */
        fun showMessage(mes: String, fancy: Boolean = false) {
            if (fancy) {
                this.mainActivity.showFancyMsg(mes)
            } else {
                Toast.makeText(
                    this.navView.context,
                    mes,
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

    }

    /**
     * Turns the translator buttons & text box back on (shows).
     */
    fun showTheTranslator() {
        this.findViewById<EditText>(R.id.textHome).isVisible = true
        if (translate) {
            this.findViewById<FloatingActionButton>(R.id.fab).isVisible = true
        } else {
            this.findViewById<FloatingActionButton>(R.id.fabSearch).isVisible = true
        }
        this.findViewById<FloatingActionButton>(R.id.fabClr).isVisible = true
        this.findViewById<FloatingActionButton>(R.id.fabClrAll).isVisible = true
        this.findViewById<FloatingActionButton>(R.id.fabSpc).isVisible = true
    }

    /**
     * Turns the translator buttons & text box off (hides).
     */
    fun hideTranslator() {
        findViewById<EditText>(R.id.textHome).isVisible = false
        findViewById<FloatingActionButton>(R.id.fab).isVisible = false
        findViewById<FloatingActionButton>(R.id.fabSearch).isVisible = false
        findViewById<FloatingActionButton>(R.id.fabClr).isVisible = false
        findViewById<FloatingActionButton>(R.id.fabClrAll).isVisible = false
        findViewById<FloatingActionButton>(R.id.fabSpc).isVisible = false
    }

    /**
     * App Initialization.
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this)
        //sharedPreferences.getInt("nightMode", MODE_NIGHT_NO)//MODE_NIGHT_YES MODE_NIGHT_FOLLOW_SYSTEM
        AppCompatDelegate.setDefaultNightMode(
            sharedPreferences.getInt(
                "nightMode",
                MODE_NIGHT_FOLLOW_SYSTEM
            )
        )
        mainActivity = this
        setSupportActionBar(binding.appBarMain.toolbar)
        firebaseAnalytics = Firebase.analytics
        val drawerLayout: DrawerLayout = binding.drawerLayout
        navView = binding.navView
        val navController = findNavController(R.id.nav_host_fragment_content_main)
        appBarConfiguration = AppBarConfiguration(
            setOf(
                R.id.nav_home,
                R.id.nav_numbers,
                R.id.nav_words,
                R.id.nav_public,
                R.id.nav_custom,
                R.id.nav_submit
            ), drawerLayout
        )
        setupActionBarWithNavController(navController, appBarConfiguration)
        navView.setupWithNavController(navController)
        if (sharedPreferences.getBoolean("loggedIn", false)) {
            navView.menu.getItem(4).isEnabled = true
            navView.menu.getItem(5).isEnabled = true
        }
        val textHome = findViewById<EditText>(R.id.textHome)
        val copyrightStr =
            getString(R.string.copy, Calendar.getInstance().get(Calendar.YEAR).toString())
        val vName = packageManager.getPackageInfo(packageName, 0).versionName
        binding.trade.text = copyrightStr
        binding.textView3.text = getString(R.string.version_display_name, vName)
        textHome.setSelectAllOnFocus(true)
        textHome.setOnClickListener {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(it, InputMethodManager.SHOW_IMPLICIT)
        }
        textHome.setOnKeyListener { view, keyCode, _ ->
            try {
                if (keyCode == KeyEvent.KEYCODE_ENTER) {
                    if (translate) {
                        textToTranslStr =
                            findViewById<EditText>(view.id).text.toString()//textHome.text.toString()
                        findNavController(R.id.nav_host_fragment_content_main).navigate(
                            R.id.nav_web
                        )
                    } else {
                        val query = textHome.text.toString()
                        if (query != "") {
                            textHome.setText("")
                            view.context.startActivity(
                                Intent(
                                    Intent.ACTION_VIEW,
                                    Uri.parse(getString(R.string.searchPrefix, query))
                                )
                            )
                        }
                    }
                }
            } catch (e: Exception) {
                errorReport(
                    errStr = "[MA-348]${e.message}",
                    errorDetails = e.stackTraceToString()
                )
            }
            return@setOnKeyListener false
        }
        val switch: SwitchCompat = findViewById(R.id.translatorSwitch)
        switch.isChecked = !translate
        binding.appBarMain.fab.isVisible = translate /* translate */
        binding.appBarMain.fabSearch.isVisible = !translate /* Search */
        switch.setOnClickListener {
            translate = !switch.isChecked
            binding.appBarMain.fab.isVisible = translate /* translate */
            binding.appBarMain.fabSearch.isVisible = !translate /* Search */
            if (translate) {
                val hint = getString(R.string.text_box_hint_translate)
                textHome.hint = hint
            } else if (!translate) {
                val hint = getString(R.string.buttonText)
                textHome.hint = hint
            }
        }
        if (translate) {
            val hint = getString(R.string.text_box_hint_translate)
            textHome.hint = hint
        } else if (!translate) {
            val hint = getString(R.string.buttonText)
            textHome.hint = hint
        }
        /* translate */
        binding.appBarMain.fab.setOnClickListener {
            try {
                val query = textHome.text.toString()
                if (query == "") {
                    showMessage(getString(R.string.searchHint), true)
                } else if (translate) {

                    textToTranslStr = textHome.text.toString()
                    textHome.setText("")
                    findNavController(R.id.nav_host_fragment_content_main).navigate(
                        R.id.nav_web
                    )
                }
            } catch (e: Exception) {
                errorReport(
                    errStr = "[MA-394]${e.message}",
                    errorDetails = e.stackTraceToString()
                )
            }
        }
        /* Search */
        binding.appBarMain.fabSearch.setOnClickListener { view: View ->
            try {
                val query = textHome.text.toString()
                if (query == "") {
                    showMessage(getString(R.string.searchHint), true)
                } else if (!translate) {
                    textHome.setText("")
                    view.context.startActivity(
                        Intent(
                            Intent.ACTION_VIEW,
                            Uri.parse(getString(R.string.searchPrefix, query))
                        )
                    )

                }
            } catch (e: Exception) {
                errorReport(
                    errStr = "[MA-417]${e.message}",
                    errorDetails = e.stackTraceToString()
                )
            }
        }
        binding.appBarMain.fabSpc.setOnClickListener {
            val oTxt = "${textHome.text} "
            textHome.setText(oTxt)
            textHome.setSelection(textHome.text.length)//textHome.setSelection(textHome.text.lastIndex.plus(1))
        }
        binding.appBarMain.fabClrAll.setOnClickListener {
            if (textHome.text.isNotEmpty()) {
                textHome.text.clear()
            }
        }
        binding.appBarMain.fabClr.setOnClickListener {
            if (textHome.text.isNotEmpty()) {
                textHome.setText(
                    textHome.text.toString().substring(0, textHome.editableText.lastIndex)
                )
                textHome.setSelection(textHome.text.length)
                // textHome.text.length   lastIndex.plus(1)
            }
        }
        binding.webText.setOnClickListener {
            binding.webText.isEnabled = false
            try {
                findNavController(R.id.nav_host_fragment_content_main).navigate(
                    R.id.nav_policy
                )
                binding.drawerLayout.close()
            } catch (e: Exception) {
                errorReport(
                    errStr = "[MA-436]${e.message}",
                    errorDetails = e.stackTraceToString()
                )
            }
            binding.webText.isEnabled = true
        }
        binding.trade.setOnClickListener {
            binding.trade.isEnabled = false
            translate = false

            /*binding.appBarMain.toolbar.title = getString(R.string.trademark)*/
            /*binding.appBarMain.toolbar.setTitle(R.string.menu_about)*/
            try {
                findNavController(R.id.nav_host_fragment_content_main).navigate(R.id.nav_web)
                binding.drawerLayout.close()
            } catch (e: Exception) {
                errorReport(
                    errStr = "[MA-451]${e.message}",
                    errorDetails = e.stackTraceToString()
                )
            }
            binding.trade.isEnabled = true
        }
        if (checkUpdate) {
            checkUpdate = false
            if (sharedPreferences.getBoolean("checkUpdate", true)) {
                /** Requests the update availability for the current app, an intent to start
                 * an update flow, and, if applicable, the state of updates currently in progress.*/
                val appUpdateManager = AppUpdateManagerFactory.create(this)
                val appUpdateInfoTask = appUpdateManager.appUpdateInfo
                // Action when the platform has an update. //AppUpdateType.FLEXIBLE AppUpdateType.IMMEDIATE
                appUpdateInfoTask.addOnSuccessListener { appUpdateInfo ->
                    if (appUpdateInfo.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE && appUpdateInfo.isUpdateTypeAllowed(
                            AppUpdateType.IMMEDIATE
                        )
                    ) {
                        // AppUpdateType.FLEXIBLE
                        // Register the listener to initiate the FLEXIBLE update.
                        /*val listener = { state: InstallState ->
                            state.installStatus()
                            if (state.installStatus() == InstallStatus.DOWNLOADED) {
                                //if (appUpdateInfo.installStatus() == InstallStatus.DOWNLOADED) {
                                // After the update is downloaded, show a notification
                                // and request user confirmation to restart the app.
                                // Display the snackbar notification and call to action.
                                Snackbar.make(
                                    binding.root,
                                    getString(R.string.updateComplete),
                                    Snackbar.LENGTH_INDEFINITE
                                ).apply {
                                    setAction(getString(R.string.restart)) { appUpdateManager.completeUpdate() }
                                    setBackgroundTint(
                                        ContextCompat.getColor(
                                            this.context,
                                            R.color.SnackBarBackground
                                        )
                                    )
                                    setActionTextColor(
                                        ContextCompat.getColor(
                                            this.context,
                                            R.color.SnackBarActionText
                                        )
                                    )
                                    setTextColor(
                                        ContextCompat.getColor(
                                            this.context,
                                            R.color.SnackBarText
                                        )
                                    )
                                    animationMode = ANIMATION_MODE_SLIDE
                                    show()
                                }
                            }

                        }
                        appUpdateManager.registerListener(listener)*/
                        // Don't use for IMMEDIATE. (doubles the update screen on finish.)
                        // .setAllowAssetPackDeletion(true).build()
                        // AppUpdateType.IMMEDIATE AppUpdateType.FLEXIBLE
                        appUpdateManager.startUpdateFlow(
                            appUpdateInfo, this, AppUpdateOptions.newBuilder(
                                AppUpdateType.IMMEDIATE
                            )
                                .build()
                        )
                    }
                }
            }
        }
        if (showAppAds) {
            if (sharedPreferences.getBoolean("showAds", true)) {
                resolveUserConsent()
            }
        }
    }

    /**
     * displays a modified snack-bar message to the user.
     */
    fun showFancyMsg(mes: String) {
        Snackbar.make(
            binding.root,
            mes,
            Snackbar.LENGTH_LONG
        ).apply {
            setAction("Ok") {
                //showMessage("thanks")
            }//,null)
            setBackgroundTint(
                ContextCompat.getColor(
                    this.context,
                    R.color.com_facebook_messenger_blue
                )
            )
            setActionTextColor(
                ContextCompat.getColor(
                    this.context,
                    R.color.com_facebook_button_text_color
                )
            )
            setTextColor(
                ContextCompat.getColor(
                    this.context,
                    R.color.com_facebook_send_button_text_color
                )
            )
            animationMode = ANIMATION_MODE_SLIDE
            show()
        }
    }

    /**
     * Create side option menu.
     */
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.main, menu)
        return true
    }

    /** Menu Options selected response. */
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_about -> {
                try {
                    findNavController(R.id.nav_host_fragment_content_main).navigate(R.id.nav_gallery)
                } catch (e: Exception) {
                    errorReport(
                        errStr = "[MA-842]${e.message}",
                        errorDetails = e.stackTraceToString()
                    )
                    try {
                        Intent.createChooser(
                            intent,
                            getString(R.string.trademark)
                        ).apply {
                            startActivity(
                                Intent(
                                    Intent.ACTION_VIEW,
                                    Uri.parse(getString(R.string.licenseLink))
                                )
                            )
                        }
                    } catch (e1: Exception) {
                        errorReport(
                            errStr = "[MA-858]${e1.message}",
                            errorDetails = e1.stackTraceToString()
                        )
                    }
                }
                return true
            }
            R.id.action_feedback -> {
                try {
                    findNavController(R.id.nav_host_fragment_content_main).navigate(R.id.nav_feedback)
                } catch (e: Exception) {
                    errorReport(
                        errStr = "[MA-869]${e.message}",
                        errorDetails = e.stackTraceToString()
                    )
                    try {
                        Intent.createChooser(
                            intent,
                            getString(R.string.trademark)
                        ).apply {
                            startActivity(
                                Intent(
                                    Intent.ACTION_VIEW,
                                    Uri.parse(getString(R.string.feedbackLink))
                                )
                            )
                        }
                    } catch (e1: Exception) {
                        errorReport(
                            errStr = "[MA-885]${e1.message}",
                            errorDetails = e1.stackTraceToString()
                        )
                    }
                }
                return true
            }
            R.id.action_play -> {
                try {
                    Intent.createChooser(
                        intent,
                        getString(R.string.trademark)
                    ).apply {
                        startActivity(
                            Intent(
                                Intent.ACTION_VIEW,
                                Uri.parse(getString(R.string.playStoreLink))
                            )
                        )
                    }
                } catch (e: Exception) {
                    errorReport(
                        errStr = "[MA-906]${e.message}",
                        errorDetails = e.stackTraceToString()
                    )
                }
                return true
            }
            R.id.action_settings -> {
                showConsentForm()
                return true
            }
            R.id.action_account_settings -> {
                try {
                    findNavController(R.id.nav_host_fragment_content_main).navigate(R.id.nav_account_settings)
                } catch (e: Exception) {
                    errorReport(
                        errStr = "[MA-921]${e.message}",
                        errorDetails = e.stackTraceToString()
                    )
                }
                return true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    /**
     * Navigation support.
     */
    override fun onSupportNavigateUp(): Boolean {
        val navController = findNavController(R.id.nav_host_fragment_content_main)
        return navController.navigateUp(appBarConfiguration) || super.onSupportNavigateUp()
    }

    /* Ad Functions */
    /**
     * Request Consent from European Users using Stack ConsentManager
     * @see(https://wiki.appodeal.com/en/android/consent-manager) */
    private fun resolveUserConsent() {

        val consentManager = com.explorestack.consent.ConsentManager.getInstance(this)
        // Consent Request info update
        consentManager.requestConsentInfoUpdate(
            APPODEAL_APP_ID,
            object : com.explorestack.consent.ConsentInfoUpdateListener {
                /**
                 * User's consent status successfully updated.
                 *  Initialize the Appodeal SDK with the received Consent object
                 *  or show the consent window. */
                override fun onConsentInfoUpdated(consent: com.explorestack.consent.Consent) {
                    /*val sharedPreferences =
                        PreferenceManager.getDefaultSharedPreferences(binding.root.context)*/
                    val sharedPreferences =
                        PreferenceManager.getDefaultSharedPreferences(this@MainActivity)
                    if (!getFileStreamPath("consent.txt").isFile) {
                        findViewById<LinearLayout>(R.id.age).isVisible = true
                        val textViewOne: TextView = findViewById(R.id.txtOne)
                        textViewOne.setOnClickListener {
                            val menuItem: MenuItem =
                                binding.appBarMain.toolbar.menu.findItem(R.id.action_settings)
                            menuItem.isVisible = true
                            findViewById<LinearLayout>(R.id.age).isVisible = false
                            sharedPreferences.edit().putBoolean("showAds", true).commit()
                            showConsentForm()
                        }
                        val textViewTwo: TextView = findViewById(R.id.txtTwo)
                        textViewTwo.setOnClickListener {
                            val menuItem: MenuItem =
                                binding.appBarMain.toolbar.menu.findItem(R.id.action_settings)
                            menuItem.isVisible = false
                            findViewById<LinearLayout>(R.id.age).isVisible = false
                            sharedPreferences.edit().putBoolean("showAds", false).commit()
                            //sharedPreferences.edit().putInt("gad_has_consent_for_cookies", 0).apply()
                            val outFile =
                                OutputStreamWriter(
                                    openFileOutput(
                                        "consent.txt",
                                        0
                                    )
                                )
                            outFile.write("isMinimumAdAge=False")
                            outFile.close()
                        }
                    } else if (consentManager.shouldShowConsentDialog() == com.explorestack.consent.Consent.ShouldShow.TRUE) {
                        showConsentForm()
                    } else {
                        consentManager.consent?.let {
                            if (sharedPreferences.getBoolean("showAds", true)) {
                                val menuItem: MenuItem =
                                    binding.appBarMain.toolbar.menu.findItem(R.id.action_settings)
                                menuItem.isVisible = true
                                //setIsAgeRestrictedUser(false, this@MainActivity)
                                //AppLovinPrivacySettings.setDoNotSell(true, context)
                                FacebookSdk.setAutoInitEnabled(true) // If disabled by manifest
                                setAutoLogAppEventsEnabled(true) // If disabled by manifest
                                setAdvertiserIDCollectionEnabled(true) // If disabled by manifest
                                FacebookSdk.fullyInitialize()
                                showAds(consent)
                            }
                        }
                    }
                }

                override fun onFailedToUpdateConsentInfo(e: com.explorestack.consent.exception.ConsentManagerException) {
                    errorReport("[MA-638] Consent Error:[${e.code}] ${e.reason}", e.reason)
                    consentError()
                }
            }
        )
    }

    /**
     * Display ConsentManger Consent request form.
     */
    fun showConsentForm() {
        if (consentForm == null) {
            consentForm = com.explorestack.consent.ConsentForm.Builder(this)
                .withListener(object : com.explorestack.consent.ConsentFormListener {
                    // Show ConsentManager Consent request form.
                    override fun onConsentFormLoaded() {
                        consentForm!!.showAsActivity()
                    }

                    /**
                    Initialize the Appodeal SDK with default params.
                     */
                    override fun onConsentFormError(exception: com.explorestack.consent.exception.ConsentManagerException) {
                        //consentError("Consent form error: [${exception.code}] ${exception.reason}")
                        consentError()
                    }

                    override fun onConsentFormOpened() {
                        //ignore
                    }

                    /**
                     * Initialize the Appodeal SDK with the received Consent.
                     */
                    override fun onConsentFormClosed(consent: com.explorestack.consent.Consent) {
                        try {
                            val sharedPreferences =
                                PreferenceManager.getDefaultSharedPreferences(this@MainActivity)
                            val outFile =
                                OutputStreamWriter(
                                    openFileOutput(
                                        "consent.txt",
                                        0
                                    )
                                )
                            when (consent.status) {
                                com.explorestack.consent.Consent.Status.PERSONALIZED -> { //3
                                    sharedPreferences.edit().putString("gad_rdpStr", "PERSONALIZED")
                                        .commit()
                                    //AppLovinPrivacySettings.setHasUserConsent(true, this@MainActivity)
                                    //sharedPreferences.edit().putInt("gad_rdp", 0).commit()

                                    //sharedPreferences.edit().putInt("gad_has_consent_for_cookies", 0).commit()
                                    outFile.write("3")
                                } // "Consent.Status.PERSONALIZED" // 3
                                com.explorestack.consent.Consent.Status.NON_PERSONALIZED -> {
                                    sharedPreferences.edit()
                                        .putString("gad_rdpStr", "NON_PERSONALIZED").commit()
                                    //AppLovinPrivacySettings.setHasUserConsent(false, this@MainActivity)
                                    //sharedPreferences.edit().putInt("gad_rdp", 1).commit()
                                    //sharedPreferences.edit().putInt("gad_has_consent_for_cookies", 0).commit()
                                    outFile.write("1")
                                } //"Consent.Status.NON_PERSONALIZED" // 1
                                com.explorestack.consent.Consent.Status.PARTLY_PERSONALIZED -> {
                                    sharedPreferences.edit()
                                        .putString("gad_rdpStr", "PARTLY_PERSONALIZED").commit()
                                    //AppLovinPrivacySettings.setHasUserConsent(true, this@MainActivity)
                                    //sharedPreferences.edit().putInt("gad_has_consent_for_cookies", 1).commit()
                                    //sharedPreferences.edit().putInt("gad_rdp", 2).commit()
                                    outFile.write("2")
                                } // "Consent.Status.PARTLY_PERSONALIZED" // 2
                                else -> {
                                    sharedPreferences.edit().putString("gad_rdpStr", "UNKNOWN")
                                        .commit()
                                    //AppLovinPrivacySettings.setHasUserConsent(false, this@MainActivity)
                                    //sharedPreferences.edit().putInt("gad_rdp", 0).commit()
                                    //sharedPreferences.edit().putInt("gad_has_consent_for_cookies", 0).commit()
                                    outFile.write("0")
                                } //"Consent.Status.UNKNOWN" // 0
                            }
                            outFile.close()
                            if (consent.status != com.explorestack.consent.Consent.Status.UNKNOWN) {
                                showAds(consent)//.status == Consent.Status.PERSONALIZED)
                            } else {
                                consentError()
                            }
                        } catch (e: Exception) {
                            errorReport(
                                errStr = "[MA-716]${e.message}",
                                errorDetails = e.stackTraceToString()
                            )
                        }
                    }
                }).build()
        }
        if (consentForm!!.isLoaded) {
            consentForm!!.showAsActivity()
        } else {
            consentForm!!.load()
        }
    }

    /**
     *  User's consent status provided.
     */
    fun showAds(consent: com.explorestack.consent.Consent) {

        try {
            /**
             *  AdMob-Ads.
             */
            MobileAds.initialize(this) {}
            /**
             *  Facebook-Ads.
             */
            AudienceNetworkInitializeHelper.initialize(this)

            /**
             *  Appodeal-Ads.
             *  Initialize Ads with resolved Consent value.
             */
            Appodeal.setBannerViewId(R.id.appodealBannerView)
            Appodeal.initialize(
                this@MainActivity,
                APPODEAL_APP_ID,
                AD_TYPE,
                consent
            )
            Appodeal.show(
                this@MainActivity,
                Appodeal.BANNER_VIEW
            )
            // (AdTypes) Appodeal.BANNER_BOTTOM)
        } catch (e: Exception) {
            errorReport(
                errStr = "[MA-790]${e.message}",
                errorDetails = e.stackTraceToString()
            )
            consentError()
        }
    }

    /**
     * User's consent status failed to update or is unknown.
     */
    fun consentError() {
        try {
            // Initialize Ads with No Consent value.
            Appodeal.setBannerViewId(R.id.appodealBannerView)
            Appodeal.initialize(
                this@MainActivity,
                APPODEAL_APP_ID,
                AD_TYPE,
                false
            )
            Appodeal.show(
                this@MainActivity,
                Appodeal.BANNER_VIEW
            )

        } catch (e: Exception) {
            errorReport(
                errStr = "[MA-816]${e.message}",
                errorDetails = e.stackTraceToString()
            )
        }
    }

    /**
     * Class that calls the initialize() method of Audience Network SDK.
     */
    internal class AudienceNetworkInitializeHelper : AudienceNetworkAds.InitListener {
        override fun onInitialized(result: AudienceNetworkAds.InitResult) {
            //errorReport("facebook-AudienceNetworkInitializeHelper:${result.message}")
            //Log.d(AudienceNetworkAds.TAG, result.message)
        }

        companion object {
            /** .withMediationService("appodeal")  ???
             * It's recommended to call this method from Application.onCreate().
             * Otherwise you can call it from all Activity.onCreate()
             * methods for Activities that contain ads.
             *
             * @param context Application or Activity.
             */
            fun initialize(context: Context?) {
                if (!AudienceNetworkAds.isInitialized(context)) {
                    if (com.facebook.share.BuildConfig.DEBUG) {
                        com.facebook.ads.AdSettings.addTestDevice("Get From Console")
                        com.facebook.ads.AdSettings.turnOnSDKDebugger(context)
                    }
                    AudienceNetworkAds
                        .buildInitSettings(context)
                        .withInitListener(AudienceNetworkInitializeHelper())
                        .initialize()
                }
            }
        }
    }
}
