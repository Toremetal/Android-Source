# <b>™T©ReMeTaL</b><br/>&nbsp; &nbsp; Signs-free
 ASL flash-card style Android™ app<br/>
https://play.google.com/store/apps/details?id=com.toremetal.signsfree
![ic_launcher-playstore](https://github.com/Toremetal/signsfree/assets/95604373/999a16ff-1a80-4c69-8db3-0b75ce7f6df3)
