/*
 *    ™T©ReMeTaL Signs A-Z.
 *    Copyright (C) 2022 ™T©ReMeTaL.
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *
 *    Some functionality created with modified (code) lessons provided by:
 *    The Android Open Source Project.
 *    Copyright (C) 2022 The Android Open Source Project.
 *    Licensed under the Apache License, Version 2.0 (the "License").
 *
 *    You may obtain a copy of the License at
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 *
 *   ************************************************************************
 *     AppData.kt : Copyright (c) 2022 ™T©ReMeTaL.
 *   ************************************************************************
 *      Computer Scientist: David W. Rick
 *      Date: 8/16/22, 1:48 AM
 *      Program Name: SignsFree
 *      File: AppData.kt
 *      Last Modified: 8/15/22, 4:20 PM
 *   ************************************************************************
 */

package com.toremetal.signsfree.data

/** Prevents the update manager from checking for updates everytime the main form loads.*/
var checkUpdate: Boolean = true

/**
 * translateAction switch.
 */
var translate: Boolean = true

/**
 * String to translate.
 */
var textToTranslStr: String = ""

/**
 * var userAccountId] holds the link value for the user's custom library.
 */
/*var userAccountId: String = ""*/

/**
 * Not Used!
 */
/*var mes: String = ""*/

/**
 * Not Used!
 */
/*var alpInit: Boolean = true*/

/**
 * Not Used!
 */
/* var loggedIn: Boolean = false*/

/**
 * Not Used!
 */
/*var convertedTextToTranslate: String = ""*/

/**
 * Not Used!
 */
/*lateinit var textToTransl: CharArray*/

/**
 * Not Used!
 */
/*var textToTranslPosition: Int = 0*/

/**
 * Not Used!
 */
/*var textToTranslLength: Int = 0*/
/**
 * Not Used!
 */
/*private val alphabet: CharArray = "ABCDEFGHIJKLMNOPQRSTUVWXYZ-".toCharArray()*/

/*//val mutableList:MutableList<cusPhotos:signsPhoto>
val alphabet: MutableList<Char> = MutableList(26) {
        index -> 'A' + index
}*/
/**
 * Not Used!
 */
/*
private fun gItem(letter: String): Int {

    if (alpInit) {
        alphabet.add(27,'-')
        alpInit=false
    }
    for (letters in alphabet) {
        if (letters.toString() == letter) {
            return alphabet.indexOf(letters)
        }
    }
    return 26
}*/
/*
    convertedTextToTranslate =""
    for (i in textToTranslStr) {
        convertedTextToTranslate += "$i,"
    }
    showMessage(convertedTextToTranslate, true)
*/