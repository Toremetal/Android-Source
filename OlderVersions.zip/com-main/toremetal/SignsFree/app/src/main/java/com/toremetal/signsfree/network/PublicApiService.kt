/*
 *    ™T©ReMeTaL Signs A-Z.
 *    Copyright (C) 2022 ™T©ReMeTaL.
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *
 *    Some functionality created with modified (code) lessons provided by:
 *    The Android Open Source Project.
 *    Copyright (C) 2022 The Android Open Source Project.
 *    Licensed under the Apache License, Version 2.0 (the "License").
 *
 *    You may obtain a copy of the License at
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 *
 *   ************************************************************************
 *     PublicApiService.kt : Copyright (c) 2022 ™T©ReMeTaL.
 *   ************************************************************************
 *      Computer Scientist: David W. Rick
 *      Date: 8/16/22, 1:48 AM
 *      Program Name: SignsFree
 *      File: PublicApiService.kt
 *      Last Modified: 8/15/22, 8:07 PM
 *   ************************************************************************
 */

package com.toremetal.signsfree.network

import androidx.annotation.Keep
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET

/**
 * The PUBLIC database url hosting app content.
 *   "https://toremetal.com/signs/"
 */
const val PUBLIC_URL: String = "https://toremetal.com/signs/"

/**
 * Build the Moshi object that Retrofit will be using,
 * adding the Kotlin adapter for full Kotlin compatibility.
 */
private val moshi = Moshi.Builder()
    .add(KotlinJsonAdapterFactory())
    .build()

/**
 * Use the Retrofit builder to build a retrofit object,
 * using a Moshi converter with our Moshi object.
 */
private val retrofit = Retrofit.Builder()
    .addConverterFactory(MoshiConverterFactory.create(moshi))
    .baseUrl(PUBLIC_URL)
    .build()

/**
 * A public interface that exposes the [getPhotos] method
 */
@Keep
interface PublicApiService {
    /**
     * Returns a [List] of [SignsPhoto] and this method can be called from a Coroutine.
     * The @GET annotation indicates that the "photos" endpoint will be requested with the GET
     * HTTP method
     */
    @GET("photos_public")
    suspend fun getPhotos(): List<SignsPhoto>
}

/**
 * A public Api object that exposes the lazy-initialized Retrofit service
 */
object PublicApi {
    /**
     * The lazy-initialized Retrofit service uses lazy to load data on demand,
     * to reduce device consumption and provide faster ui response.
     */
    val retrofitService: PublicApiService by lazy { retrofit.create(PublicApiService::class.java) }
}
