/*
 *    ™T©ReMeTaL Signs A-Z.
 *    Copyright (C) 2022 ™T©ReMeTaL.
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *
 *    Some functionality created with modified (code) lessons provided by:
 *    The Android Open Source Project.
 *    Copyright (C) 2022 The Android Open Source Project.
 *    Licensed under the Apache License, Version 2.0 (the "License").
 *
 *    You may obtain a copy of the License at
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 *
 *   ************************************************************************
 *     GalleryFragment.kt : Copyright (c) 2022 ™T©ReMeTaL.
 *   ************************************************************************
 *      Computer Scientist: David W. Rick
 *      Date: 8/16/22, 1:48 AM
 *      Program Name: SignsFree
 *      File: GalleryFragment.kt
 *      Last Modified: 8/15/22, 4:48 PM
 *   ************************************************************************
 */

package com.toremetal.signsfree.ui.gallery

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.toremetal.signsfree.R
import com.toremetal.signsfree.databinding.FragmentGalleryBinding
import com.toremetal.signsfree.hideTranslator
import com.toremetal.signsfree.showTranslator

/**
 * The About Container.
 */
class GalleryFragment : Fragment() {

    private lateinit var galleryViewModel: GalleryViewModel
    private var _binding: FragmentGalleryBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    /**
     *
     */
    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        galleryViewModel =
            ViewModelProvider(this)[GalleryViewModel::class.java]
        _binding = FragmentGalleryBinding.inflate(inflater, container, false)
        val root: View = binding.root
        val webViewer: WebView = binding.webView
        webViewer.loadUrl(getString(R.string.licenseLink))
        webViewer.webViewClient = MyWebViewClient()
        webViewer.settings.javaScriptEnabled = true
        return root
    }

    /**
     * public open fun onResume():
     * Unit Description copied from class: androidx.fragment.app.Fragment
     * Called when the fragment is visible to the user and actively running.
     * This is generally tied to Activity.onResume of the containing Activity's lifecycle.
     * Overrides: [onResume] in class Fragment.
     *
     * [In this app Usage:]
     *
     * Hides the translator functions while displaying the settings menu.
     * Works consistently placed here. Since the view is only created once when the function
     * is placed in the [onCreate] the function does not run when resuming causing
     * the translator to display when switching between light and dark mode.
     */
    override fun onResume() {
        super.onResume()
        hideTranslator()
    }

    /**
     * Turns the translator buttons & text box back on.
     */
    override fun onPause() {
        super.onPause()
        showTranslator()
    }

    /**
     *
     */
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

private class MyWebViewClient : WebViewClient() {
    override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
        if (Uri.parse(url).host == "www.toremetal.com") {
            // This is my web site, so do not override; let my WebView load the page
            return false
        }
        if (Uri.parse(url).host == "toremetal.com") {
            // This is my web site, so do not override; let my WebView load the page
            return false
        }
        // Otherwise, the link is not for a page on my site, so launch another Activity that handles URLs
        view?.context?.startActivity(
            Intent(
                Intent.ACTION_VIEW,
                Uri.parse(url)
            )
        )
        return true
    }
}