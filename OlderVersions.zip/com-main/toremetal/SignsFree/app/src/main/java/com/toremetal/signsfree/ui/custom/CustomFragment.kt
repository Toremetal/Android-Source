/*
 *    ™T©ReMeTaL Signs A-Z.
 *    Copyright (C) 2022 ™T©ReMeTaL.
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *
 *    Some functionality created with modified (code) lessons provided by:
 *    The Android Open Source Project.
 *    Copyright (C) 2022 The Android Open Source Project.
 *    Licensed under the Apache License, Version 2.0 (the "License").
 *
 *    You may obtain a copy of the License at
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 *
 *   ************************************************************************
 *     CustomFragment.kt : Copyright (c) 2022 ™T©ReMeTaL.
 *   ************************************************************************
 *      Computer Scientist: David W. Rick
 *      Date: 8/16/22, 1:48 AM
 *      Program Name: SignsFree
 *      File: CustomFragment.kt
 *      Last Modified: 8/15/22, 1:24 AM
 *   ************************************************************************
 */

package com.toremetal.signsfree.ui.custom

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.toremetal.signsfree.databinding.FragmentCustomBinding
import com.toremetal.signsfree.ui.home.PhotoGridAdapter

/**
 *
 */
class CustomFragment : Fragment() {
    private val viewModel: CustomViewModel by viewModels()
    private var _binding: FragmentCustomBinding? = null
    private val binding get() = _binding!!

    /**
     * Override to provide access to the Grid Adapter on View Creation.
     */
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentCustomBinding.inflate(inflater)
        binding.viewModel = viewModel
        binding.lifecycleOwner = this.viewLifecycleOwner
        binding.photosGrid.adapter = PhotoGridAdapter()
        return binding.root
    }

    /**
     * Release all resources associated with the view.
     */
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}