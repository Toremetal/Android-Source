# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.
#
# For more details, see
#   http://developer.android.com/guide/developing/tools/proguard.html

-printconfiguration build/outputs/mapping/full-r8-config.txt

# Uncomment this to preserve the line number information for
# debugging stack traces.
-keepattributes SourceFile,LineNumberTable

# If you keep the line number information, uncomment this to
# hide the original source file name.
-renamesourcefileattribute SourceFile

# Preserve annotated Javascript interface methods.
-keepclassmembers class com.toremetal.signsfree.ui.image.WebAppInterface {
    @android.webkit.JavascriptInterface <methods>;
}
