/*
 *    ™T©ReMeTaL Signs A-Z+.
 *    Copyright (C) 2022 ™T©ReMeTaL.
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *
 *    Some functionality created with modified (code) lessons provided by:
 *    The Android Open Source Project.
 *    Copyright (C) 2022 The Android Open Source Project.
 *    Licensed under the Apache License, Version 2.0 (the "License").
 *
 *    You may obtain a copy of the License at
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 *
 *   ************************************************************************
 *     SettingsFragment.kt : Copyright (c) 2022 ™T©ReMeTaL.
 *   ************************************************************************
 *      Computer Scientist: David W. Rick
 *      Date: 8/16/22, 2:53 AM
 *      Program Name: Signs
 *      File: SettingsFragment.kt
 *      Last Modified: 8/16/22, 2:34 AM
 *   ************************************************************************
 */

package com.toremetal.signs.ui.settings

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.app.AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
import androidx.appcompat.app.AppCompatDelegate.MODE_NIGHT_YES
import androidx.preference.PreferenceFragmentCompat
import androidx.preference.PreferenceManager
import androidx.preference.SwitchPreferenceCompat
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.toremetal.signs.*
import com.toremetal.signs.MainActivity.MyNavView.showMessage

/**
 *
 */
class SettingsFragment : PreferenceFragmentCompat() {

    /**
     *
     */
    @SuppressLint("ApplySharedPref")
    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        setPreferencesFromResource(R.xml.root_preferences, rootKey)
        this.findPreference<SwitchPreferenceCompat>("nightModeBool")?.setOnPreferenceClickListener {
            val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(requireContext())
            if (sharedPreferences.getBoolean("nightModeBool", false)) {
                if (sharedPreferences.getInt(
                        "nightMode",
                        MODE_NIGHT_FOLLOW_SYSTEM
                    ) == MODE_NIGHT_FOLLOW_SYSTEM
                ) {
                    sharedPreferences.edit().putInt("nightMode", MODE_NIGHT_YES).commit()
                    AppCompatDelegate.setDefaultNightMode(MODE_NIGHT_YES)
                }
            } else if (sharedPreferences.getInt(
                    "nightMode",
                    MODE_NIGHT_FOLLOW_SYSTEM
                ) != MODE_NIGHT_FOLLOW_SYSTEM
            ) {
                sharedPreferences.edit().putInt("nightMode", MODE_NIGHT_FOLLOW_SYSTEM).commit()
                AppCompatDelegate.setDefaultNightMode(MODE_NIGHT_FOLLOW_SYSTEM)
            }
            true
        }
        this.findPreference<SwitchPreferenceCompat>("signIn")?.setOnPreferenceClickListener {

            val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(requireContext())
            if (this.findPreference<SwitchPreferenceCompat>("signIn")!!.isChecked) {

                //if (!sharedPreferences.getBoolean("loggedIn", false)) {
                val email = sharedPreferences.getString("email", "")
                val pas = sharedPreferences.getString("password", "").toString()
                if (email != "") {
                    if (pas != "") {
                        val encEmail =
                            email?.replace("@toremetal.com", "-10101")
                                ?.replace("@gmail.com", "-00000")
                                ?.replace("@outlook.com", "-11111")
                                ?.replace("@live.com", "-22222")
                                ?.replace("@yahoo.com", "-33333")
                                ?.replace("@hotmail.com", "-44444")
                                ?.replace("@aol.com", "-55555")?.replace("office.com", "-66666")
                                ?.replace("@", "_t-t-")?.replace(".com", "_tod-")?.lowercase()
                        //val encPass = pass.replace("1", ".^}.").replace("2", ".^].").replace("3", ".^;.").replace("4", ".^_.").replace("5", ".^-.").replace("6", ".^[.").replace("7", ".^{.").replace("8", ".^$.").replace("9", ".^*.").replace("0", ".$.").replace("a", "'1").replace( "b", "'2").replace("c", "'3").replace("d", "'4").replace("e", "'5").replace("f", "'6").replace("g", "'7").replace("h", "'8").replace("i", "'9").replace("j", "'0").replace("k", "'-").replace("r", "'_").replace("l", "',").replace("m", "'^").replace("n", "';").replace("o", "'[").replace("p", "']").replace("q", "',").replace("s", "'(").replace("t", "'=").replace("u", "'@").replace("v", "'#").replace("w", "'$").replace("x", "'!").replace("y", "'}").replace("z", "'{")
                        val queue = Volley.newRequestQueue(requireContext())
                        val url =
                            "https://toremetal.com/signs?appsign=true&em=$encEmail&pa=$pas"
                        // Request a string response from the provided URL.
                        val stringRequest = StringRequest(
                            Request.Method.POST, url,
                            { response ->
                                if (response.substring(0, 4) == "true") {
                                    if (response.substring(4, response.length) != "") {
                                        val lib = response.substring(4, response.length)
                                        sharedPreferences.edit().putString("library", lib)
                                            .commit()
                                        MainActivity.menuButtonOn(true)
                                        val mes = "LogIn Successful"
                                        sharedPreferences.edit().putBoolean("loggedIn", true)
                                            .commit()
                                        refreshMyScrn(mes)
                                    } else {
                                        val mes = "log-in Error"
                                        refreshMyScrn(mes)
                                    }
                                } else {
                                    val mes = "log-in Error: $response"
                                    refreshMyScrn(mes)
                                }
                            },
                            {
                                val mes = "log-in Error (net error)"
                                MainActivity.errorReport(
                                    "log-in Error (net error:${it.message}",
                                    it.stackTraceToString()
                                )
                                showMessage(mes)
                            })
                        queue.add(stringRequest)
                    }
                }
                //}
            } else if (!this.findPreference<SwitchPreferenceCompat>("signIn")!!.isChecked) {
                try {
                    val mes = "Logged Out"
                    sharedPreferences.edit().putBoolean("loggedIn", false).commit()
                    sharedPreferences.edit().putString("library", "").commit()
                    MainActivity.menuButtonOn(false)
                    refreshMyScrn(mes)
                } catch (e: Exception) {
                    MainActivity.errorReport(e.message.toString(), e.stackTraceToString())
                }
            }
            true
        }

    }

    /**
     * public open fun onResume():
     * Unit Description copied from class: androidx.fragment.app.Fragment
     * Called when the fragment is visible to the user and actively running.
     * This is generally tied to Activity.onResume of the containing Activity's lifecycle.
     * Overrides: [onResume] in class Fragment.
     *
     * [In this app Usage:]
     *
     * Hides the translator functions while displaying the settings menu.
     * Works consistently placed here. Since the view is only created once when the function
     * is placed in the [onCreatePreferences] the function does not run when resuming causing
     * the translator to display when switching between light and dark mode.
     */
    override fun onResume() {
        super.onResume()
        hideTranslator()
    }

    /**
     * Turns the translator buttons & text box back on.
     */
    override fun onPause() {
        super.onPause()
        showTranslator()
    }
}