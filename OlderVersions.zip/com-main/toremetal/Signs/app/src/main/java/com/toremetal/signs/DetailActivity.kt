/*
 *    ™T©ReMeTaL Signs A-Z+.
 *    Copyright (C) 2022 ™T©ReMeTaL.
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *
 *    Some functionality created with modified (code) lessons provided by:
 *    The Android Open Source Project.
 *    Copyright (C) 2022 The Android Open Source Project.
 *    Licensed under the Apache License, Version 2.0 (the "License").
 *
 *    You may obtain a copy of the License at
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 *
 *   ************************************************************************
 *     DetailActivity.kt : Copyright (c) 2022 ™T©ReMeTaL.
 *   ************************************************************************
 *      Computer Scientist: David W. Rick
 *      Date: 8/16/22, 2:53 AM
 *      Program Name: Signs
 *      File: DetailActivity.kt
 *      Last Modified: 8/10/22, 5:23 PM
 *   ************************************************************************
 */

package com.toremetal.signs

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.toremetal.signs.MainActivity.MyNavView.errorReport
import com.toremetal.signs.databinding.ActivityDetailBinding

/**
 * Detail Activity displays individual images to the user.
 */
class DetailActivity : AppCompatActivity() {
    companion object {
        /**
         * val LETTER is used to display a custom title to the user.
         */
        const val LETTER: String = "letter"
        //const val IMG = "letter"
    }

    /**
     * The Initial entry point for the detail activity.
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val letterId = intent?.extras?.getString(LETTER).toString()
        //val imgUrls = intent?.extras?.getString(IMG).toString()
        val imgUrl = intent?.data.toString()
        val myWebView = binding.webView
        myWebView.loadUrl(imgUrl)
        myWebView.contentDescription = letterId
        myWebView.settings.setSupportZoom(true)
        myWebView.settings.builtInZoomControls = true
        myWebView.settings.displayZoomControls = true
        val searchButton: FloatingActionButton = binding.button
        val searchText = "${getString(R.string.buttonText)}: $letterId"
        val searchQry = getString(R.string.searchPrefix, letterId)
        searchButton.contentDescription = searchText
        searchButton.setOnClickListener {
            try {
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    /*type =
                        ContactsContract.CommonDataKinds.Website.MIMETYPE*/
                    data =
                        Uri.parse(searchQry)
                }
                Intent.createChooser(intent, "™T©ReMeTaL").apply {
                    it.context.startActivity(intent)
                }
            } catch (e: Exception) {
                errorReport(
                    errStr = "[DA-88]${e.message}",
                    errorDetails = e.stackTraceToString()
                )
            }
        }
        title = getString(R.string.detail_prefix) + " " + letterId.uppercase()
    }
}