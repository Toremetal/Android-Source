/*
 *    ™T©ReMeTaL Signs A-Z+.
 *    Copyright (C) 2022 ™T©ReMeTaL.
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *
 *    Some functionality created with modified (code) lessons provided by:
 *    The Android Open Source Project.
 *    Copyright (C) 2022 The Android Open Source Project.
 *    Licensed under the Apache License, Version 2.0 (the "License").
 *
 *    You may obtain a copy of the License at
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 *
 *   ************************************************************************
 *     ImageFragment.kt : Copyright (c) 2022 ™T©ReMeTaL.
 *   ************************************************************************
 *      Computer Scientist: David W. Rick
 *      Date: 8/16/22, 2:53 AM
 *      Program Name: Signs
 *      File: ImageFragment.kt
 *      Last Modified: 8/16/22, 2:34 AM
 *   ************************************************************************
 */

package com.toremetal.signs.ui.image

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.annotation.Keep
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.preference.PreferenceManager
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.google.android.material.snackbar.Snackbar
import com.toremetal.signs.MainActivity.MyNavView.showMessage
import com.toremetal.signs.R
import com.toremetal.signs.databinding.FragmentImageBinding
import com.toremetal.signs.hideTranslator
import com.toremetal.signs.showTranslator

/**
 *  The Login and submission method handler.
 */
@SuppressLint("SetJavaScriptEnabled", "ApplySharedPref")
class ImageFragment : Fragment() {
    private lateinit var imageViewModel: ImageViewModel
    private var _binding: FragmentImageBinding? = null
    private val binding get() = _binding!!

    /**
     * Called when the fragment is visible to the user and actively running.
     * This is generally
     * tied to [onResume] of the containing
     * Activity's lifecycle.
     */
    override fun onResume() {
        val sharedPreferences =
            PreferenceManager.getDefaultSharedPreferences(requireContext())
        val editor: Boolean = sharedPreferences.getBoolean("edit", false)
        binding.chip4.isChecked = editor
        if (editor) {
            val webViewer: WebView = binding.webView
            if (!sharedPreferences.getBoolean("editLogin", false)) {
                val email = sharedPreferences.getString("email", "").toString()
                val em =
                    email.replace("@toremetal.com", "-10101").replace("@gmail.com", "-00000")
                        .replace("@outlook.com", "-11111").replace("@live.com", "-22222")
                        .replace("@yahoo.com", "-33333").replace("@hotmail.com", "-44444")
                        .replace("@aol.com", "-55555").replace("office.com", "-66666")
                        .replace("@", "_t-t-").replace(".com", "_tod-").lowercase()
                val pas = sharedPreferences.getString("password", "").toString()
                webViewer.loadUrl("${getString(R.string.subLink)}?ret=editfile&appsign=true&pa=$pas&em=$em")
                sharedPreferences.edit().putBoolean("editLogin", true).commit()
            } else {
                webViewer.loadUrl("${getString(R.string.subLink)}?ret=editfile")
            }

            webViewer.webViewClient = MyWebViewClient()
            webViewer.settings.javaScriptEnabled = true
            webViewer.addJavascriptInterface(WebAppInterface(requireContext()), "Android")
            binding.submit.visibility = View.GONE
            binding.webView.visibility = View.VISIBLE
            binding.chip4.isCloseIconVisible = true
        }
        super.onResume()
    }

    /**
     *
     */
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        imageViewModel =
            ViewModelProvider(this)[ImageViewModel::class.java]
        hideTranslator()
        _binding = FragmentImageBinding.inflate(inflater, container, false)
        val root: View = binding.root
        val sharedPreferences =
            PreferenceManager.getDefaultSharedPreferences(requireContext())
        binding.submitImage.setOnClickListener {
            binding.submitImage.isEnabled = false
            val imgLnk = binding.imageLink.text.toString()
            val imgName = binding.imageName.text.toString()
            if (imgLnk != getString(R.string.https)) {
                if (imgLnk != "") {
                    if (imgName != "") {
                        val em = sharedPreferences.getString("email", "").toString()
                        val pass = sharedPreferences.getString("password", "").toString()
                        val lib = sharedPreferences.getString("library", "").toString()
                        val accType = "Personal" // Public
                        /*val encEmail = email?.replace("@toremetal.com", "-10101")?.replace("@gmail.com", "-00000")
                                    ?.replace("@outlook.com", "-11111")?.replace("@live.com", "-22222")
                                    ?.replace("@yahoo.com", "-33333")?.replace("@hotmail.com", "-44444")
                                    ?.replace("@aol.com", "-55555")?.replace("office.com", "-66666")
                                    ?.replace("@", "_t-t-")?.replace(".com", "_tod-")?.lowercase()*/
                        var encPass = ""
                        for (ch in pass) {
                            encPass += ch.toString().replace("1", ".^}.").replace("2", ".^].")
                                .replace("3", ".^;.")
                                .replace("4", ".^_.").replace("5", ".^-.").replace("6", ".^[.")
                                .replace("7", ".^{.").replace("8", ".^$.").replace("9", ".^*.")
                                .replace("0", ".$.").replace("a", "'1").replace("b", "'2")
                                .replace("c", "'3").replace("d", "'4").replace("e", "'5")
                                .replace("f", "'6")
                                .replace("g", "'7").replace("h", "'8").replace("i", "'9")
                                .replace("j", "'0")
                                .replace("k", "'-").replace("r", "'_").replace("l", "',")
                                .replace("m", "'^")
                                .replace("n", "';").replace("o", "'[").replace("p", "']")
                                .replace("q", "',")
                                .replace("s", "'(").replace("t", "'=").replace("u", "'@")
                                .replace("v", "'#")
                                .replace("w", "'$").replace("x", "'!").replace("y", "'}")
                                .replace("z", "'{")
                        }
                        val queue = Volley.newRequestQueue(requireContext())
                        val url =
                            "https://toremetal.com/signs?em=$em&pa=$encPass&accType=$accType&lib=$lib&name=$imgName&url=$imgLnk&appsubmit=Submit"
                        // Request a string response from the provided URL.
                        val stringRequest = StringRequest(
                            Request.Method.POST, url,
                            { response ->
                                showMessage(response, fancy = true)
                            },
                            {
                                Snackbar.make(
                                    this.requireView(),
                                    "ERROR: (net error:${it.localizedMessage})",
                                    Snackbar.LENGTH_SHORT
                                )
                                    .setAction("Action", null).show()
                            })
                        queue.add(stringRequest)
                        binding.imageLink.setText("")
                        binding.imageName.setText("")
                    } else {
                        showMessage(getString(R.string.enterImageName), fancy = true)
                    }
                } else {
                    showMessage(getString(R.string.enterImageLink), fancy = true)
                }
            } else {
                showMessage(getString(R.string.enterImageLink), fancy = true)
            }
            binding.submitImage.isEnabled = true
        }
        binding.preview.setOnClickListener {
            binding.webView.loadUrl(binding.imageLink.text.toString())
            binding.webView.visibility = View.VISIBLE
        }

        binding.chip4.setOnClickListener {

            if (binding.chip4.isChecked) {
                sharedPreferences.edit().putBoolean("edit", true).commit()
            } else if (!binding.chip4.isChecked) {
                sharedPreferences.edit().putBoolean("edit", false).commit()
            }
            if (binding.submit.visibility == View.VISIBLE) {
                val webViewer: WebView = binding.webView
                if (!sharedPreferences.getBoolean("editLogin", false)) {
                    val email = sharedPreferences.getString("email", "").toString()
                    val em =
                        email.replace("@toremetal.com", "-10101").replace("@gmail.com", "-00000")
                            .replace("@outlook.com", "-11111").replace("@live.com", "-22222")
                            .replace("@yahoo.com", "-33333").replace("@hotmail.com", "-44444")
                            .replace("@aol.com", "-55555").replace("office.com", "-66666")
                            .replace("@", "_t-t-").replace(".com", "_tod-").lowercase()
                    val pas = sharedPreferences.getString("password", "").toString()
                    webViewer.loadUrl("${getString(R.string.subLink)}?ret=editfile&appsign=true&pa=$pas&em=$em")
                    sharedPreferences.edit().putBoolean("editLogin", true).commit()
                } else {
                    webViewer.loadUrl("${getString(R.string.subLink)}?ret=editfile")
                }

                webViewer.webViewClient = MyWebViewClient()
                webViewer.settings.javaScriptEnabled = true
                webViewer.addJavascriptInterface(WebAppInterface(requireContext()), "Android")
                binding.submit.visibility = View.GONE
                binding.webView.visibility = View.VISIBLE
                binding.chip4.isCloseIconVisible = true
            } else {
                binding.chip4.isCloseIconVisible = false
                val imgStr = binding.imageLink.text.toString()
                var viewVisible = View.GONE
                if (imgStr != getString(R.string.https)) {
                    if (imgStr.length > 7) {
                        if (imgStr.substring(0, 4) == "http") {
                            /*binding.webView.loadUrl(binding.imageLink.text.toString())*/
                            val webViewer: WebView = binding.webView
                            webViewer.loadUrl(binding.imageLink.text.toString())
                            webViewer.webViewClient = MyWebViewClient()
                            webViewer.settings.javaScriptEnabled = false
                            viewVisible = View.VISIBLE
                        }
                    }
                }
                binding.webView.visibility = viewVisible
                binding.submit.visibility = View.VISIBLE
            }
        }
        return root
    }

    /**
     * Turns the translator buttons & text box back on.
     */
    override fun onPause() {
        super.onPause()
        showTranslator()
    }

    /**
     *
     */
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

}

private class MyWebViewClient : WebViewClient() {
    override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
        val urlStr = Uri.parse(url).toString()
        if (urlStr.length > 42) {
            if (urlStr.substring(0, 43) == "https://toremetal.com/signs/?ret=uploadform") {
                view?.context?.startActivity(
                    Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse(url)
                    )
                )
                return true
            }
        }
        if (Uri.parse(url).host == "www.toremetal.com") {
            return false
        }
        if (Uri.parse(url).host == "toremetal.com") {
            return false
        }
        view?.context?.startActivity(
            Intent(
                Intent.ACTION_VIEW,
                Uri.parse(url)
            )
        )
        return true
    }
}

/** Instantiate the interface and set the context  */
@Keep
class WebAppInterface(private val mContext: Context) {

    /** Show a toast from the web page  */
    @SuppressLint("ApplySharedPref")
    @JavascriptInterface
    fun showToast(toast: String) {
        val sharedPreferences =
            PreferenceManager.getDefaultSharedPreferences(mContext)
        val loggedIn = when (toast) {
            "logged in" -> {
                true
            }
            "logged out" -> {
                false
            }
            else -> {
                sharedPreferences.getBoolean("editLogin", false)
            }
        }
        sharedPreferences.edit().putBoolean("editLogin", loggedIn).commit()
        showMessage(toast)
        android.widget.Toast.makeText(mContext, toast, android.widget.Toast.LENGTH_SHORT).show()
    }
}