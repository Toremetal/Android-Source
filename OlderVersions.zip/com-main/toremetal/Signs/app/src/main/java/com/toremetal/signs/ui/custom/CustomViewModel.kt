/*
 *    ™T©ReMeTaL Signs A-Z+.
 *    Copyright (C) 2022 ™T©ReMeTaL.
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *
 *    Some functionality created with modified (code) lessons provided by:
 *    The Android Open Source Project.
 *    Copyright (C) 2022 The Android Open Source Project.
 *    Licensed under the Apache License, Version 2.0 (the "License").
 *
 *    You may obtain a copy of the License at
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 *
 *   ************************************************************************
 *     CustomViewModel.kt : Copyright (c) 2022 ™T©ReMeTaL.
 *   ************************************************************************
 *      Computer Scientist: David W. Rick
 *      Date: 8/16/22, 2:53 AM
 *      Program Name: Signs
 *      File: CustomViewModel.kt
 *      Last Modified: 8/10/22, 5:23 PM
 *   ************************************************************************
 */

package com.toremetal.signs.ui.custom

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.toremetal.signs.network.CustomApi
import com.toremetal.signs.network.SignsPhoto
import com.toremetal.signs.ui.home.SignsApiStatus
import kotlinx.coroutines.launch

/**
 * The custom viewModel allows users to create a custom image library for personal use.
 */
class CustomViewModel : ViewModel() {

    /**
     * The internal MutableLiveData that stores the status of the most recent request.
     */
    private val _status = MutableLiveData<SignsApiStatus>()

    /**
     * The external immutable LiveData for the request status.
     */
    val status: LiveData<SignsApiStatus> = _status

    /**
     * The internal MutableLiveData that stores the photos of the most recent request.
     */
    private val _photos = MutableLiveData<List<SignsPhoto>>()

    /**
     * The external LiveData interface is immutable, so only this class can modify it.
     */
    val photos: LiveData<List<SignsPhoto>> = _photos

    /**
     * Call getSignsPhotos() on init so we can display status immediately.
     */
    init {
        getSignsPhotos()
    }

    /**
     * Gets Signs photos information from the Signs API service and updates the
     * [SignsPhoto] [List] [LiveData].
     */
    private fun getSignsPhotos() {

        viewModelScope.launch {
            _status.value = SignsApiStatus.LOADING
            try {
                _photos.value = CustomApi.retrofitService.getPhotos()
                _status.value = SignsApiStatus.DONE
            } catch (e: Exception) {
                _status.value = SignsApiStatus.ERROR
                _photos.value = listOf()
            }
        }
    }
}