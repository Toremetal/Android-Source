/*
 *    ™T©ReMeTaL Signs A-Z+.
 *    Copyright (C) 2022 ™T©ReMeTaL.
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *
 *    Some functionality created with modified (code) lessons provided by:
 *    The Android Open Source Project.
 *    Copyright (C) 2022 The Android Open Source Project.
 *    Licensed under the Apache License, Version 2.0 (the "License").
 *
 *    You may obtain a copy of the License at
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 *
 *   ************************************************************************
 *     MainActivity.kt : Copyright (c) 2022 ™T©ReMeTaL.
 *   ************************************************************************
 *      Computer Scientist: David W. Rick
 *      Date: 8/16/22, 2:53 AM
 *      Program Name: Signs
 *      File: MainActivity.kt
 *      Last Modified: 8/16/22, 2:42 AM
 *   ************************************************************************
 */

package com.toremetal.signs

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.KeyEvent
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.app.AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
import androidx.appcompat.widget.SwitchCompat
import androidx.core.app.ActivityCompat.recreate
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.drawerlayout.widget.DrawerLayout
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import androidx.preference.PreferenceManager
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.navigation.NavigationView
import com.google.android.material.snackbar.BaseTransientBottomBar.ANIMATION_MODE_SLIDE
import com.google.android.material.snackbar.Snackbar
import com.google.android.play.core.appupdate.AppUpdateManagerFactory
import com.google.android.play.core.appupdate.AppUpdateOptions
import com.google.android.play.core.install.InstallState
import com.google.android.play.core.install.model.AppUpdateType
import com.google.android.play.core.install.model.InstallStatus
import com.google.android.play.core.install.model.UpdateAvailability
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.analytics.ktx.analytics
import com.google.firebase.ktx.Firebase
import com.toremetal.signs.MainActivity.MyNavView.mainActivity
import com.toremetal.signs.MainActivity.MyNavView.showMessage
import com.toremetal.signs.data.checkUpdate
import com.toremetal.signs.data.textToTranslStr
import com.toremetal.signs.data.translate
import com.toremetal.signs.databinding.ActivityMainBinding
import java.util.*

/**
 * Global display Error-Message Switch for debugging.
 *
 * set: { const val [showErrorMessage]: Boolean = false } for release.
 */
const val showErrorMessage: Boolean = false

/**
 * Function [refreshMyScrn] applies changes made by fragments that require an app refresh to work
 * properly. Without this the app needs to be rotated or restarted to properly activate the custom
 * library. Which likely caused the app to appear as a total piece of crap to end users.
 * This may be the solution to using fragments and getting smooth productivity.
 *
 *   note: ***Requires
 *
 *      fun refreshMyScrn() {
 *          recreate(mainActivity)
 *      }
 *      class MainActivity : AppCompatActivity() {
 *          companion object MyNavView {
 *              lateinit var mainActivity: MainActivity
 *          }
 *          override fun onCreate(savedInstanceState: Bundle?) {
 *              super.onCreate(savedInstanceState)
 *              binding = ActivityMainBinding.inflate(layoutInflater)
 *              setContentView(binding.root)
 *              mainActivity = this
 *          }
 *      }
 */
fun refreshMyScrn(mes: String = "") {
    recreate(mainActivity)
    if (mes != "") {
        showMessage(mes)
    }
}

/**
 * External function: [tLater] is used to pass user input
 * to the Internal function: [MainActivity.setTxtWebInput]
 * to set the text in the web-search text-box.
 */
fun tLater(str: String) {
    mainActivity.setTxtWebInput(str)
}

/**
 * Turns the translator buttons & text box back on.
 */
fun showTranslator() {
    mainActivity.showTheTranslator()
}

/**
 * Turns the translator buttons & text box off (hides).
 */
fun hideTranslator() {
    mainActivity.hideTranslator()
}

/**
 * [MainActivity] The primary container for the application.
 */
class MainActivity : AppCompatActivity() {
    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActivityMainBinding
    private lateinit var firebaseAnalytics: FirebaseAnalytics

    /**
     * Internal function to set the text in the webSearch text-box.
     */
    fun setTxtWebInput(newText: String) {
        val textHome = findViewById<EditText>(R.id.textHome)
        val txt = "${textHome.text}$newText"
        textHome.setText(txt)
        textHome.setSelection(textHome.text.length)
        //textHome.setSelection(textHome.editableText.lastIndex.plus(1))
    }

    /** [UPDATE! Problem Solved Using: refreshMyScrn() ]
     * Seeking best method to allow fragment to enable/disable menu option at log in/out.
     *   note: it works inconsistently. logcat seems to display this error on log in.
     *   E/ERROR: Only the original thread that created a view hierarchy can touch its views.
     */
    companion object MyNavView {

        /**
         * [navView] Nav Menu assigned as a global var to allow fragments to disable options.
         */
        lateinit var navView: NavigationView

        /**
         * Var [mainActivity] is the handle used to refresh the application allowing
         * any changes made to fully take effect giving accurate feedback to the user.
         *
         *      note: This may allow the perform click to work requesting it this
         *           way may be how to get the call to come from the same library.
         */
        lateinit var mainActivity: MainActivity

        /**
         * function to activate/deactivate nav menu options
         *
         *  note: currently used for 1 option. Add an Int variable to get different menu items.
         *
         *      fun menuButtonOn(on: Boolean, item: Int) {
         *          navView.menu.getItem(item).isEnabled = on
         *      }
         */
        fun menuButtonOn(on: Boolean) {
            try {
                navView.menu.getItem(4).isEnabled = on
                navView.menu.getItem(5).isEnabled = on
            } catch (e: Exception) {
                errorReport(
                    errStr = "[MA-238]${e.message}",
                    errorDetails = e.stackTraceToString()
                )
            }
        }

        /**
         * (User Optional Error Reporting.) Error Logged by the host site.
         */
        fun errorReport(errStr: String, errorDetails: String = "") {
            val sharedPreferences =
                PreferenceManager.getDefaultSharedPreferences(this.navView.context /* Activity context */)
            if (sharedPreferences.getBoolean("sendErrors", false)) {
                var details = ""
                if (sharedPreferences.getBoolean("detail", false)) {
                    details = "&detail=$errorDetails"
                }
                try {
                    val queue = Volley.newRequestQueue(this.navView.context)
                    /*val url =
                        "https://script.google.com/macros/s/AKfycbzgPsTwAQQkPG5YC_gjZPhGU1dYVYycMNOfFs25TXypg1FJSUpOET_6NnoAe7LL0ixo/exec?error=$errStr$details&app=SignsA-Z"*/
                    val url = "https://toremetal.com/log/?error=$errStr$details&app=SignsA-Z"
                    // Request a string response from the provided URL.
                    val stringRequest = StringRequest(
                        Request.Method.POST, url,
                        { response ->
                            val vx: CharSequence = "Not Logged"
                            if (response.contains(vx, ignoreCase = false)) {
                                if (showErrorMessage) {
                                    showMessage("[Log Error:] $response")
                                }
                            } else {
                                if (showErrorMessage) {
                                    showMessage(response)
                                }
                            }
                        }, {
                            this.errorReport(
                                errStr = "[MA-239]${it.message}",
                                errorDetails = it.stackTraceToString()
                            )
                        })
                    queue.add(stringRequest)
                } catch (e: Exception) {
                    this.errorReport(
                        errStr = "[MA-245]${e.message}",
                        errorDetails = e.stackTraceToString()
                    )
                }
            }
        }

        /**
         * Function: [showMessage] displays a popup message to the user.
         *
         *   note: SnackBar does not work when passing messages BETWEEN fragments on view change,
         *
         *      Must use:
         *        Toast.makeText(this.navView.context, mes, Toast.LENGTH_SHORT).show()
         *
         *     To use this showMessage on View Changing events. Static-view messages display
         *     fine. However, when the view is switching there is no View?. for the SnackBar
         *     whereas the Toast uses App {context} not an Active {view} which doesn't
         *     dispose() during View Changing events. (theoretical, but logical.)
         *
         *       note2:
         *       Could Global function this outside the class & pass the context to it.
         *          this would eliminate the need for a companion object.
         *          fun showMessage(mes: String, context: Context) {}
         *
         *          toUse: showMessage("", this.requireContext())
         */
        fun showMessage(mes: String, fancy: Boolean = false) {
            if (fancy) {
                this.mainActivity.showFancyMsg(mes)
            } else {
                Toast.makeText(
                    this.navView.context,
                    mes,
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    /**
     * Turns the translator buttons & text box back on (shows).
     */
    fun showTheTranslator() {
        this.findViewById<EditText>(R.id.textHome).isVisible = true
        if (translate) {
            this.findViewById<FloatingActionButton>(R.id.fab).isVisible = true
        } else {
            this.findViewById<FloatingActionButton>(R.id.fab1).isVisible = true
        }
        this.findViewById<FloatingActionButton>(R.id.fabClr).isVisible = true
        this.findViewById<FloatingActionButton>(R.id.fabClrAll).isVisible = true
        this.findViewById<FloatingActionButton>(R.id.fabSpc).isVisible = true
    }

    /**
     * Turns the translator buttons & text box off (hides).
     */
    fun hideTranslator() {
        findViewById<EditText>(R.id.textHome).isVisible = false
        findViewById<FloatingActionButton>(R.id.fab).isVisible = false
        findViewById<FloatingActionButton>(R.id.fab1).isVisible = false
        findViewById<FloatingActionButton>(R.id.fabClr).isVisible = false
        findViewById<FloatingActionButton>(R.id.fabClrAll).isVisible = false
        findViewById<FloatingActionButton>(R.id.fabSpc).isVisible = false
    }

    /**
     * App Initialization.
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this)
        //sharedPreferences.getInt("nightMode", MODE_NIGHT_NO)//MODE_NIGHT_YES MODE_NIGHT_FOLLOW_SYSTEM
        AppCompatDelegate.setDefaultNightMode(
            sharedPreferences.getInt(
                "nightMode",
                MODE_NIGHT_FOLLOW_SYSTEM
            )
        )
        mainActivity = this
        setSupportActionBar(binding.appBarMain.toolbar)
        firebaseAnalytics = Firebase.analytics
        val drawerLayout: DrawerLayout = binding.drawerLayout
        navView = binding.navView
        val navController = findNavController(R.id.nav_host_fragment_content_main)
        appBarConfiguration = AppBarConfiguration(
            setOf(
                R.id.nav_home,
                R.id.nav_numbers,
                R.id.nav_words,
                R.id.nav_public,
                R.id.nav_custom,
                R.id.nav_submit
            ), drawerLayout
        )
        setupActionBarWithNavController(navController, appBarConfiguration)
        navView.setupWithNavController(navController)
        //val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this)
        if (sharedPreferences.getBoolean("loggedIn", false)) {
            navView.menu.getItem(4).isEnabled = true
            navView.menu.getItem(5).isEnabled = true
        }
        val textHome = findViewById<EditText>(R.id.textHome)
        val copyrightStr =
            getString(R.string.copy, Calendar.getInstance().get(Calendar.YEAR).toString())
        val vName = packageManager.getPackageInfo(packageName, 0).versionName
        binding.trade.text = copyrightStr
        binding.textView3.text = getString(R.string.version_display_name, vName)
        textHome.setSelectAllOnFocus(true)
        textHome.setOnClickListener {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(it, InputMethodManager.SHOW_IMPLICIT)
        }
        textHome.setOnKeyListener { view, keyCode, _ ->
            try {
                if (keyCode == KeyEvent.KEYCODE_ENTER) {
                    if (translate) {
                        textToTranslStr =
                            findViewById<EditText>(view.id).text.toString()//textHome.text.toString()
                        findNavController(R.id.nav_host_fragment_content_main).navigate(
                            R.id.nav_web
                        )
                    } else {
                        val query = textHome.text.toString()
                        if (query != "") {
                            textHome.setText("")
                            view.context.startActivity(
                                Intent(
                                    Intent.ACTION_VIEW,
                                    Uri.parse(getString(R.string.searchPrefix, query))
                                )
                            )
                        }
                    }
                }
            } catch (e: Exception) {
                errorReport(
                    errStr = "[MA-348]${e.message}",
                    errorDetails = e.stackTraceToString()
                )
            }
            return@setOnKeyListener false
        }
        val switch: SwitchCompat = findViewById(R.id.translatorSwitch)
        switch.isChecked = !translate
        binding.appBarMain.fab.isVisible = translate /* translate */
        binding.appBarMain.fab1.isVisible = !translate /* Search */
        switch.setOnClickListener {
            translate = !switch.isChecked
            binding.appBarMain.fab.isVisible = translate /* translate */
            binding.appBarMain.fab1.isVisible = !translate /* Search */
            if (translate) {
                val hint = getString(R.string.text_box_hint_translate)
                textHome.hint = hint
            } else if (!translate) {
                val hint = getString(R.string.buttonText)
                textHome.hint = hint
            }
        }
        if (translate) {
            val hint = getString(R.string.text_box_hint_translate)
            textHome.hint = hint
        } else if (!translate) {
            val hint = getString(R.string.buttonText)
            textHome.hint = hint
        }
        /* translate */
        binding.appBarMain.fab.setOnClickListener {
            try {
                val query = textHome.text.toString()
                if (query == "") {
                    showMessage(getString(R.string.searchHint), true)
                } else if (translate) {

                    textToTranslStr = textHome.text.toString()
                    textHome.setText("")
                    findNavController(R.id.nav_host_fragment_content_main).navigate(
                        R.id.nav_web
                    )
                }
            } catch (e: Exception) {
                errorReport(
                    errStr = "[MA-394]${e.message}",
                    errorDetails = e.stackTraceToString()
                )
            }
        }
        /* Search */
        binding.appBarMain.fab1.setOnClickListener { view: View ->
            try {
                val query = textHome.text.toString()
                if (query == "") {
                    showMessage(getString(R.string.searchHint), true)
                } else if (!translate) {
                    textHome.setText("")
                    view.context.startActivity(
                        Intent(
                            Intent.ACTION_VIEW,
                            Uri.parse(getString(R.string.searchPrefix, query))
                        )
                    )

                }
            } catch (e: Exception) {
                errorReport(
                    errStr = "[MA-417]${e.message}",
                    errorDetails = e.stackTraceToString()
                )
            }
        }
        binding.appBarMain.fabSpc.setOnClickListener {
            val oTxt = "${textHome.text} "
            textHome.setText(oTxt)
            textHome.setSelection(textHome.text.length)//textHome.setSelection(textHome.text.lastIndex.plus(1))
        }
        binding.appBarMain.fabClrAll.setOnClickListener {
            if (textHome.text.isNotEmpty()) {
                textHome.text.clear()
            }
        }
        binding.appBarMain.fabClr.setOnClickListener {
            if (textHome.text.isNotEmpty()) {
                textHome.setText(
                    textHome.text.toString().substring(0, textHome.editableText.lastIndex)
                )
                textHome.setSelection(textHome.text.length)
                // textHome.text.length   lastIndex.plus(1)
            }
        }
        binding.webText.setOnClickListener {
            binding.webText.isEnabled = false
            try {
                findNavController(R.id.nav_host_fragment_content_main).navigate(
                    R.id.nav_policy
                )
                binding.drawerLayout.close()
            } catch (e: Exception) {
                errorReport(
                    errStr = "[MA-436]${e.message}",
                    errorDetails = e.stackTraceToString()
                )
            }
            binding.webText.isEnabled = true
        }
        binding.trade.setOnClickListener {
            binding.trade.isEnabled = false
            translate = false

            /*binding.appBarMain.toolbar.title = getString(R.string.trademark)*/
            /*binding.appBarMain.toolbar.setTitle(R.string.menu_about)*/
            try {
                findNavController(R.id.nav_host_fragment_content_main).navigate(R.id.nav_web)
                binding.drawerLayout.close()
            } catch (e: Exception) {
                errorReport(
                    errStr = "[MA-451]${e.message}",
                    errorDetails = e.stackTraceToString()
                )
            }
            binding.trade.isEnabled = true
        }
        if (checkUpdate) {
            checkUpdate = false
            if (sharedPreferences.getBoolean("checkUpdate", true)) {
                /** Requests the update availability for the current app, an intent to start
                 * an update flow, and, if applicable, the state of updates currently in progress.*/
                val appUpdateManager = AppUpdateManagerFactory.create(this)
                val appUpdateInfoTask = appUpdateManager.appUpdateInfo
                // Action when the platform has an update. //AppUpdateType.FLEXIBLE AppUpdateType.IMMEDIATE
                appUpdateInfoTask.addOnSuccessListener { appUpdateInfo ->
                    if (appUpdateInfo.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE && appUpdateInfo.isUpdateTypeAllowed(
                            AppUpdateType.IMMEDIATE
                        )
                    ) {
                        val listener = { state: InstallState ->
                            state.installStatus()
                            if (state.installStatus() == InstallStatus.DOWNLOADED) {
                                //if (appUpdateInfo.installStatus() == InstallStatus.DOWNLOADED) {
                                // After the update is downloaded, show a notification
                                // and request user confirmation to restart the app.
                                // Display the snackbar notification and call to action.
                                Snackbar.make(
                                    binding.root,
                                    getString(R.string.updateComplete),
                                    Snackbar.LENGTH_INDEFINITE
                                ).apply {
                                    setAction(getString(R.string.restart)) { appUpdateManager.completeUpdate() }
                                    setBackgroundTint(
                                        ContextCompat.getColor(
                                            this.context,
                                            R.color.SnackBarBackground
                                        )
                                    )
                                    setActionTextColor(
                                        ContextCompat.getColor(
                                            this.context,
                                            R.color.SnackBarActionText
                                        )
                                    )
                                    setTextColor(
                                        ContextCompat.getColor(
                                            this.context,
                                            R.color.SnackBarText
                                        )
                                    )
                                    animationMode = ANIMATION_MODE_SLIDE
                                    show()
                                }
                            }

                        }
                        appUpdateManager.registerListener(listener)
                        // .setAllowAssetPackDeletion(true).build()
                        // AppUpdateType.IMMEDIATE AppUpdateType.FLEXIBLE
                        appUpdateManager.startUpdateFlow(
                            appUpdateInfo, this, AppUpdateOptions.newBuilder(
                                AppUpdateType.IMMEDIATE
                            )
                                .build()
                        )
                    }
                }
            }
        }
    }

    /**
     * displays a modified snack-bar message to the user.
     */
    fun showFancyMsg(mes: String) {
        Snackbar.make(
            binding.root,
            mes,
            Snackbar.LENGTH_LONG
        ).apply {
            setAction("Ok") {
                //showMessage("thanks")
            }//,null)
            setBackgroundTint(
                ContextCompat.getColor(
                    this.context,
                    R.color.SnackBarBackground
                )
            )
            setActionTextColor(
                ContextCompat.getColor(
                    this.context,
                    R.color.SnackBarActionText
                )
            )
            setTextColor(
                ContextCompat.getColor(
                    this.context,
                    R.color.SnackBarText
                )
            )
            animationMode = ANIMATION_MODE_SLIDE
            show()
        }
    }

    /**
     * Create side option menu.
     */
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.main, menu)
        return true
    }

    /** Menu Options selected response. */
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_about -> {
                try {
                    findNavController(R.id.nav_host_fragment_content_main).navigate(R.id.nav_gallery)
                } catch (e: Exception) {
                    errorReport(
                        errStr = "[MA-842]${e.message}",
                        errorDetails = e.stackTraceToString()
                    )
                    try {
                        Intent.createChooser(
                            intent,
                            getString(R.string.trademark)
                        ).apply {
                            startActivity(
                                Intent(
                                    Intent.ACTION_VIEW,
                                    Uri.parse(getString(R.string.licenseLink))
                                )
                            )
                        }
                    } catch (e1: Exception) {
                        errorReport(
                            errStr = "[MA-858]${e1.message}",
                            errorDetails = e1.stackTraceToString()
                        )
                    }
                }
                return true
            }
            R.id.action_feedback -> {
                try {
                    findNavController(R.id.nav_host_fragment_content_main).navigate(R.id.nav_feedback)
                } catch (e: Exception) {
                    errorReport(
                        errStr = "[MA-869]${e.message}",
                        errorDetails = e.stackTraceToString()
                    )
                    try {
                        Intent.createChooser(
                            intent,
                            getString(R.string.trademark)
                        ).apply {
                            startActivity(
                                Intent(
                                    Intent.ACTION_VIEW,
                                    Uri.parse(getString(R.string.feedbackLink))
                                )
                            )
                        }
                    } catch (e1: Exception) {
                        errorReport(
                            errStr = "[MA-885]${e1.message}",
                            errorDetails = e1.stackTraceToString()
                        )
                    }
                }
                return true
            }
            R.id.action_play -> {
                try {
                    Intent.createChooser(
                        intent,
                        getString(R.string.trademark)
                    ).apply {
                        startActivity(
                            Intent(
                                Intent.ACTION_VIEW,
                                Uri.parse(getString(R.string.playStoreLink))
                            )
                        )
                    }
                } catch (e: Exception) {
                    errorReport(
                        errStr = "[MA-906]${e.message}",
                        errorDetails = e.stackTraceToString()
                    )
                }
                return true
            }
            R.id.action_account_settings -> {
                try {
                    findNavController(R.id.nav_host_fragment_content_main).navigate(R.id.nav_account_settings)
                } catch (e: Exception) {
                    errorReport(
                        errStr = "[MA-921]${e.message}",
                        errorDetails = e.stackTraceToString()
                    )
                }
                return true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    /**
     * Navigation support.
     */
    override fun onSupportNavigateUp(): Boolean {
        val navController = findNavController(R.id.nav_host_fragment_content_main)
        return navController.navigateUp(appBarConfiguration) || super.onSupportNavigateUp()
    }
}