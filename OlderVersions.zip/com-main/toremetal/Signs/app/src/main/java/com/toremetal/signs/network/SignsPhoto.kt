/*
 *    ™T©ReMeTaL Signs A-Z+.
 *    Copyright (C) 2022 ™T©ReMeTaL.
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *
 *    Some functionality created with modified (code) lessons provided by:
 *    The Android Open Source Project.
 *    Copyright (C) 2022 The Android Open Source Project.
 *    Licensed under the Apache License, Version 2.0 (the "License").
 *
 *    You may obtain a copy of the License at
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 *
 *   ************************************************************************
 *     SignsPhoto.kt : Copyright (c) 2022 ™T©ReMeTaL.
 *   ************************************************************************
 *      Computer Scientist: David W. Rick
 *      Date: 8/16/22, 2:53 AM
 *      Program Name: Signs
 *      File: SignsPhoto.kt
 *      Last Modified: 8/10/22, 5:23 PM
 *   ************************************************************************
 */

package com.toremetal.signs.network

import androidx.annotation.Keep
import com.squareup.moshi.Json

/**
 * This data class defines a Signs photo which includes an ID, and the image URL.
 * The property names of this data class are used by Moshi to match the names of values in JSON.
 */
@Keep
data class SignsPhoto(
    /**
     * used to map id from the JSON to id in our class
     */
    val id: String,

    /**
     * used to map img_src from the JSON to imgSrcUrl in our class
     */
    @Json(name = "img_src") val imgSrcUrl: String,
    /**
     * used to map img_val from the JSON to img_val in our class
     */
    @Json(name = "img_val") val imgVal: String
)